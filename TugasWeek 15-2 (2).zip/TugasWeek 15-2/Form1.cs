﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasWeek_15_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static string[] makanan = new string[100];
        public static string[] minuman = new string[100];
        public int counter;
        public int counter2;

        private void Form1_Load(object sender, EventArgs e)
        {
            listBoxDaftar.SelectionMode = SelectionMode.MultiSimple;
            listBoxCopy.SelectionMode = SelectionMode.MultiSimple;
            makanan[0] = "Mie Instan";
            makanan[1] = "Telor";
            makanan[2] = "Roti";
            makanan[3] = "Keju";
            makanan[4] = "Daging Giling";
            counter = 5;

            minuman[0] = "Susu Sapi";
            minuman[1] = "Kopi";
            minuman[2] = "Teh";
            minuman[3] = "Bir";
            counter2 = 4;

            listBoxMakanan.Visible = false;
            listBoxMinuman.Visible = false;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= listBoxDaftar.SelectedIndices.Count - 1; i++)
            {
                if (!listBoxCopy.Items.Contains(listBoxDaftar.SelectedItems[i]))
                {
                    listBoxCopy.Items.Add(listBoxDaftar.SelectedItems[i]);
                }
            }
            listBoxDaftar.ClearSelected();
        }

        private void buttonInput_Click(object sender, EventArgs e)
        {
            if (textBoxItem.Text == "" || !radioButtonMakanan.Checked && !radioButtonMinuman.Checked)
            {
                MessageBox.Show("Data Belum Lengkap");
            }
            else if (listBoxDaftar.Items.Contains(textBoxItem.Text))
            {
                MessageBox.Show("Input Gagal");
            }
            else
            {
                listBoxDaftar.Items.Add(textBoxItem.Text);
                if (radioButtonMakanan.Checked == true)
                {
                    //int counter = 5;
                    counter++;
                    makanan[counter] = textBoxItem.Text;
                    listBoxMakanan.Items.Add(makanan[counter]);
                }
                else if (radioButtonMinuman.Checked == true)
                {
                    //int counter2 = 4;
                    counter2++;
                    minuman[counter2] = textBoxItem.Text;
                    listBoxMinuman.Items.Add(minuman[counter2]);
                }
            }
            textBoxItem.Text = "";
            radioButtonMakanan.Checked = false;
            radioButtonMinuman.Checked = false;
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ListBox.SelectedObjectCollection selected = new ListBox.SelectedObjectCollection(listBoxCopy);

            if (listBoxCopy.SelectedIndex != -1)
            {
                for (int i = selected.Count - 1; i >= 0; i--)
                {
                    listBoxCopy.Items.Remove(selected[i]);
                }
            }
            else
            {
                listBoxCopy.Items.Clear();
            }
        }

        private void radioButtonMakanan_Click(object sender, EventArgs e)
        {

        }

        private void radioButtonMakanan_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonMinuman_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBoxMakanan_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxMakanan.Checked == true)
            {
                for (int i = 0; i < counter; i++)
                {
                    if (makanan[i] != "" )
                    {
                        listBoxDaftar.SetSelected(listBoxDaftar.FindString(makanan[i]), true);
                    }
                }
            }
        }
            private void checkBoxMinuman_CheckedChanged(object sender, EventArgs e)
            {
                if (checkBoxMinuman.Checked == true)
                {
                    listBoxMakanan.Visible = false;
                    listBoxDaftar.Visible = false;
                    listBoxMinuman.Visible = true;
                    for (int i = 0; i < listBoxMinuman.Items.Count; i++)
                    {
                        listBoxMinuman.SetSelected(i, true);
                    }
                }
                else if (checkBoxMinuman.Checked == false)
                {
                    listBoxMakanan.Visible = false;
                    listBoxDaftar.Visible = true;
                    listBoxMinuman.Visible = false;
                    for (int i = 0; i < listBoxMinuman.Items.Count; i++)
                    {
                        listBoxMinuman.SetSelected(i, false);
                    }
                }
            }
    }
 } 

