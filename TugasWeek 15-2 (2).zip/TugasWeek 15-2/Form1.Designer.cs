﻿namespace TugasWeek_15_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelInput = new System.Windows.Forms.Label();
            this.labelKategori = new System.Windows.Forms.Label();
            this.textBoxItem = new System.Windows.Forms.TextBox();
            this.radioButtonMakanan = new System.Windows.Forms.RadioButton();
            this.radioButtonMinuman = new System.Windows.Forms.RadioButton();
            this.panelKategori = new System.Windows.Forms.Panel();
            this.buttonInput = new System.Windows.Forms.Button();
            this.listBoxDaftar = new System.Windows.Forms.ListBox();
            this.buttonCopy = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.labelFilter = new System.Windows.Forms.Label();
            this.checkBoxMakanan = new System.Windows.Forms.CheckBox();
            this.checkBoxMinuman = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listBoxCopy = new System.Windows.Forms.ListBox();
            this.listBoxMinuman = new System.Windows.Forms.ListBox();
            this.listBoxMakanan = new System.Windows.Forms.ListBox();
            this.panelKategori.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelInput
            // 
            this.labelInput.AutoSize = true;
            this.labelInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInput.Location = new System.Drawing.Point(43, 41);
            this.labelInput.Name = "labelInput";
            this.labelInput.Size = new System.Drawing.Size(73, 16);
            this.labelInput.TabIndex = 0;
            this.labelInput.Text = "Nama Item";
            // 
            // labelKategori
            // 
            this.labelKategori.AutoSize = true;
            this.labelKategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKategori.Location = new System.Drawing.Point(43, 99);
            this.labelKategori.Name = "labelKategori";
            this.labelKategori.Size = new System.Drawing.Size(58, 16);
            this.labelKategori.TabIndex = 1;
            this.labelKategori.Text = "Kategori";
            // 
            // textBoxItem
            // 
            this.textBoxItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxItem.Location = new System.Drawing.Point(177, 36);
            this.textBoxItem.Name = "textBoxItem";
            this.textBoxItem.Size = new System.Drawing.Size(187, 22);
            this.textBoxItem.TabIndex = 2;
            // 
            // radioButtonMakanan
            // 
            this.radioButtonMakanan.AutoSize = true;
            this.radioButtonMakanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonMakanan.Location = new System.Drawing.Point(16, 12);
            this.radioButtonMakanan.Name = "radioButtonMakanan";
            this.radioButtonMakanan.Size = new System.Drawing.Size(82, 20);
            this.radioButtonMakanan.TabIndex = 3;
            this.radioButtonMakanan.TabStop = true;
            this.radioButtonMakanan.Text = "Makanan";
            this.radioButtonMakanan.UseVisualStyleBackColor = true;
            this.radioButtonMakanan.CheckedChanged += new System.EventHandler(this.radioButtonMakanan_CheckedChanged);
            this.radioButtonMakanan.Click += new System.EventHandler(this.radioButtonMakanan_Click);
            // 
            // radioButtonMinuman
            // 
            this.radioButtonMinuman.AutoSize = true;
            this.radioButtonMinuman.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonMinuman.Location = new System.Drawing.Point(137, 12);
            this.radioButtonMinuman.Name = "radioButtonMinuman";
            this.radioButtonMinuman.Size = new System.Drawing.Size(80, 20);
            this.radioButtonMinuman.TabIndex = 4;
            this.radioButtonMinuman.TabStop = true;
            this.radioButtonMinuman.Text = "Minuman";
            this.radioButtonMinuman.UseVisualStyleBackColor = true;
            this.radioButtonMinuman.CheckedChanged += new System.EventHandler(this.radioButtonMinuman_CheckedChanged);
            // 
            // panelKategori
            // 
            this.panelKategori.Controls.Add(this.radioButtonMakanan);
            this.panelKategori.Controls.Add(this.radioButtonMinuman);
            this.panelKategori.Location = new System.Drawing.Point(177, 83);
            this.panelKategori.Name = "panelKategori";
            this.panelKategori.Size = new System.Drawing.Size(220, 46);
            this.panelKategori.TabIndex = 5;
            // 
            // buttonInput
            // 
            this.buttonInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInput.Location = new System.Drawing.Point(177, 136);
            this.buttonInput.Name = "buttonInput";
            this.buttonInput.Size = new System.Drawing.Size(75, 27);
            this.buttonInput.TabIndex = 6;
            this.buttonInput.Text = "Input";
            this.buttonInput.UseVisualStyleBackColor = true;
            this.buttonInput.Click += new System.EventHandler(this.buttonInput_Click);
            // 
            // listBoxDaftar
            // 
            this.listBoxDaftar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxDaftar.FormattingEnabled = true;
            this.listBoxDaftar.ItemHeight = 16;
            this.listBoxDaftar.Items.AddRange(new object[] {
            "Mie Instan",
            "Telor",
            "Susu Sapi",
            "Kopi",
            "Roti",
            "Keju",
            "Daging Giling",
            "Teh",
            "Bir"});
            this.listBoxDaftar.Location = new System.Drawing.Point(46, 183);
            this.listBoxDaftar.Name = "listBoxDaftar";
            this.listBoxDaftar.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxDaftar.Size = new System.Drawing.Size(174, 260);
            this.listBoxDaftar.TabIndex = 7;
            // 
            // buttonCopy
            // 
            this.buttonCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCopy.Location = new System.Drawing.Point(242, 183);
            this.buttonCopy.Name = "buttonCopy";
            this.buttonCopy.Size = new System.Drawing.Size(122, 27);
            this.buttonCopy.TabIndex = 8;
            this.buttonCopy.Text = ">";
            this.buttonCopy.UseVisualStyleBackColor = true;
            this.buttonCopy.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDelete.Location = new System.Drawing.Point(245, 216);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(119, 27);
            this.buttonDelete.TabIndex = 9;
            this.buttonDelete.Text = "X";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // labelFilter
            // 
            this.labelFilter.AutoSize = true;
            this.labelFilter.Location = new System.Drawing.Point(13, 0);
            this.labelFilter.Name = "labelFilter";
            this.labelFilter.Size = new System.Drawing.Size(29, 13);
            this.labelFilter.TabIndex = 10;
            this.labelFilter.Text = "Filter";
            // 
            // checkBoxMakanan
            // 
            this.checkBoxMakanan.AutoSize = true;
            this.checkBoxMakanan.Location = new System.Drawing.Point(6, 24);
            this.checkBoxMakanan.Name = "checkBoxMakanan";
            this.checkBoxMakanan.Size = new System.Drawing.Size(71, 17);
            this.checkBoxMakanan.TabIndex = 11;
            this.checkBoxMakanan.Text = "Makanan";
            this.checkBoxMakanan.UseVisualStyleBackColor = true;
            this.checkBoxMakanan.CheckedChanged += new System.EventHandler(this.checkBoxMakanan_CheckedChanged);
            // 
            // checkBoxMinuman
            // 
            this.checkBoxMinuman.AutoSize = true;
            this.checkBoxMinuman.Location = new System.Drawing.Point(6, 47);
            this.checkBoxMinuman.Name = "checkBoxMinuman";
            this.checkBoxMinuman.Size = new System.Drawing.Size(69, 17);
            this.checkBoxMinuman.TabIndex = 12;
            this.checkBoxMinuman.Text = "Minuman";
            this.checkBoxMinuman.UseVisualStyleBackColor = true;
            this.checkBoxMinuman.CheckedChanged += new System.EventHandler(this.checkBoxMinuman_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxMinuman);
            this.panel1.Controls.Add(this.labelFilter);
            this.panel1.Controls.Add(this.checkBoxMakanan);
            this.panel1.Location = new System.Drawing.Point(245, 259);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(119, 89);
            this.panel1.TabIndex = 13;
            // 
            // listBoxCopy
            // 
            this.listBoxCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxCopy.FormattingEnabled = true;
            this.listBoxCopy.ItemHeight = 16;
            this.listBoxCopy.Location = new System.Drawing.Point(392, 183);
            this.listBoxCopy.Name = "listBoxCopy";
            this.listBoxCopy.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxCopy.Size = new System.Drawing.Size(174, 260);
            this.listBoxCopy.TabIndex = 14;
            // 
            // listBoxMinuman
            // 
            this.listBoxMinuman.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMinuman.FormattingEnabled = true;
            this.listBoxMinuman.ItemHeight = 16;
            this.listBoxMinuman.Items.AddRange(new object[] {
            "Susu Sapi",
            "Kopi",
            "Teh",
            "Bir"});
            this.listBoxMinuman.Location = new System.Drawing.Point(46, 183);
            this.listBoxMinuman.Name = "listBoxMinuman";
            this.listBoxMinuman.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxMinuman.Size = new System.Drawing.Size(174, 260);
            this.listBoxMinuman.TabIndex = 15;
            // 
            // listBoxMakanan
            // 
            this.listBoxMakanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMakanan.FormattingEnabled = true;
            this.listBoxMakanan.ItemHeight = 16;
            this.listBoxMakanan.Items.AddRange(new object[] {
            "Mie Instan",
            "Telor",
            "Roti",
            "Keju",
            "Daging Giling"});
            this.listBoxMakanan.Location = new System.Drawing.Point(46, 183);
            this.listBoxMakanan.Name = "listBoxMakanan";
            this.listBoxMakanan.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxMakanan.Size = new System.Drawing.Size(174, 260);
            this.listBoxMakanan.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 530);
            this.Controls.Add(this.listBoxCopy);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonCopy);
            this.Controls.Add(this.listBoxDaftar);
            this.Controls.Add(this.buttonInput);
            this.Controls.Add(this.textBoxItem);
            this.Controls.Add(this.labelKategori);
            this.Controls.Add(this.labelInput);
            this.Controls.Add(this.panelKategori);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBoxMakanan);
            this.Controls.Add(this.listBoxMinuman);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelKategori.ResumeLayout(false);
            this.panelKategori.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInput;
        private System.Windows.Forms.Label labelKategori;
        private System.Windows.Forms.TextBox textBoxItem;
        private System.Windows.Forms.RadioButton radioButtonMakanan;
        private System.Windows.Forms.RadioButton radioButtonMinuman;
        private System.Windows.Forms.Panel panelKategori;
        private System.Windows.Forms.Button buttonInput;
        private System.Windows.Forms.ListBox listBoxDaftar;
        private System.Windows.Forms.Button buttonCopy;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Label labelFilter;
        private System.Windows.Forms.CheckBox checkBoxMakanan;
        private System.Windows.Forms.CheckBox checkBoxMinuman;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox listBoxCopy;
        private System.Windows.Forms.ListBox listBoxMinuman;
        private System.Windows.Forms.ListBox listBoxMakanan;
    }
}

