﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PraktikumWeek13__2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonProses_Click(object sender, EventArgs e)
        {
            if (labelEmpty.Text == "[EMPTY]")
            {
                labelEmpty.Text = textBoxInput.Text;
            }
            else if (labelEmpty.Text!= "[EMPTY]" && textBoxInput.Text == "DELETE")
            {
                labelEmpty.Text = "[EMPTY]";
            }
            else if (labelEmpty.Text != "[EMPTY]" && textBoxInput.Text == "SHOWN")
            {
                labelEmpty.Visible = true;
            }
            else if (labelEmpty.Text != "[EMPTY]" && textBoxInput.Text == "HIDE")
            {
                labelEmpty.Visible = false;
            }
            else if (labelEmpty.Text != "[EMPTY]" && textBoxInput.Text == "BLUE")
            {
                labelEmpty.ForeColor = Color.Blue;
            }
            else if (labelEmpty.Text != "[EMPTY]" && textBoxInput.Text == "RED")
            {
                labelEmpty.ForeColor = Color.Red;
            }
            else if (labelEmpty.Text != "[EMPTY]"  && textBoxInput.Text == "GREEN")
            {
                labelEmpty.ForeColor = Color.Green;
            }
        }
    }
}
