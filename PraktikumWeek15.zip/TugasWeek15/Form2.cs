﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasWeek15
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
       // public int harga = Form1
        public int subtotal = 0;
        
        private void buttonHitung_Click(object sender, EventArgs e)
        {
          //  for (int i = 0; i <)
        }

        private void checkBoxDisc_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxDisc.Checked = false)
            {
                labelInput.Visible = false;
                labelPersen.Visible = false;
                textBoxInput.Visible = false;
            }
            else
            {
                labelInput.Visible = true;
                labelPersen.Visible = true;
                textBoxInput.Visible = true;
            }
        }
    }
}
