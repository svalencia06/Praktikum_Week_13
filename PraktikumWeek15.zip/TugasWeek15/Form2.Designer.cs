﻿namespace TugasWeek15
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.checkBoxDisc = new System.Windows.Forms.CheckBox();
            this.labelInput = new System.Windows.Forms.Label();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.buttonHitung = new System.Windows.Forms.Button();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelDisc = new System.Windows.Forms.Label();
            this.labelSubTotal = new System.Windows.Forms.Label();
            this.labelTax = new System.Windows.Forms.Label();
            this.labelTotal2 = new System.Windows.Forms.Label();
            this.labelDisc2 = new System.Windows.Forms.Label();
            this.labelTax2 = new System.Windows.Forms.Label();
            this.labelSubtotal2 = new System.Windows.Forms.Label();
            this.labelPersen = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // checkBoxDisc
            // 
            this.checkBoxDisc.AutoSize = true;
            this.checkBoxDisc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDisc.Location = new System.Drawing.Point(33, 41);
            this.checkBoxDisc.Name = "checkBoxDisc";
            this.checkBoxDisc.Size = new System.Drawing.Size(111, 24);
            this.checkBoxDisc.TabIndex = 0;
            this.checkBoxDisc.Text = "DISCOUNT";
            this.checkBoxDisc.UseVisualStyleBackColor = true;
            this.checkBoxDisc.CheckedChanged += new System.EventHandler(this.checkBoxDisc_CheckedChanged);
            // 
            // labelInput
            // 
            this.labelInput.AutoSize = true;
            this.labelInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInput.Location = new System.Drawing.Point(55, 95);
            this.labelInput.Name = "labelInput";
            this.labelInput.Size = new System.Drawing.Size(36, 16);
            this.labelInput.TabIndex = 1;
            this.labelInput.Text = "Input";
            // 
            // textBoxInput
            // 
            this.textBoxInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxInput.Location = new System.Drawing.Point(98, 95);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(100, 22);
            this.textBoxInput.TabIndex = 2;
            // 
            // buttonHitung
            // 
            this.buttonHitung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHitung.Location = new System.Drawing.Point(33, 147);
            this.buttonHitung.Name = "buttonHitung";
            this.buttonHitung.Size = new System.Drawing.Size(97, 29);
            this.buttonHitung.TabIndex = 3;
            this.buttonHitung.Text = "CALCULATE";
            this.buttonHitung.UseVisualStyleBackColor = true;
            this.buttonHitung.Click += new System.EventHandler(this.buttonHitung_Click);
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(368, 160);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(39, 16);
            this.labelTotal.TabIndex = 4;
            this.labelTotal.Text = "Total";
            // 
            // labelDisc
            // 
            this.labelDisc.AutoSize = true;
            this.labelDisc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDisc.Location = new System.Drawing.Point(368, 127);
            this.labelDisc.Name = "labelDisc";
            this.labelDisc.Size = new System.Drawing.Size(60, 16);
            this.labelDisc.TabIndex = 5;
            this.labelDisc.Text = "Discount";
            // 
            // labelSubTotal
            // 
            this.labelSubTotal.AutoSize = true;
            this.labelSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSubTotal.Location = new System.Drawing.Point(368, 65);
            this.labelSubTotal.Name = "labelSubTotal";
            this.labelSubTotal.Size = new System.Drawing.Size(57, 16);
            this.labelSubTotal.TabIndex = 6;
            this.labelSubTotal.Text = "Subtotal";
            // 
            // labelTax
            // 
            this.labelTax.AutoSize = true;
            this.labelTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTax.Location = new System.Drawing.Point(368, 95);
            this.labelTax.Name = "labelTax";
            this.labelTax.Size = new System.Drawing.Size(31, 16);
            this.labelTax.TabIndex = 7;
            this.labelTax.Text = "Tax";
            // 
            // labelTotal2
            // 
            this.labelTotal2.AutoSize = true;
            this.labelTotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal2.Location = new System.Drawing.Point(526, 160);
            this.labelTotal2.Name = "labelTotal2";
            this.labelTotal2.Size = new System.Drawing.Size(0, 16);
            this.labelTotal2.TabIndex = 8;
            // 
            // labelDisc2
            // 
            this.labelDisc2.AutoSize = true;
            this.labelDisc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDisc2.Location = new System.Drawing.Point(526, 127);
            this.labelDisc2.Name = "labelDisc2";
            this.labelDisc2.Size = new System.Drawing.Size(0, 16);
            this.labelDisc2.TabIndex = 9;
            // 
            // labelTax2
            // 
            this.labelTax2.AutoSize = true;
            this.labelTax2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTax2.Location = new System.Drawing.Point(526, 95);
            this.labelTax2.Name = "labelTax2";
            this.labelTax2.Size = new System.Drawing.Size(0, 16);
            this.labelTax2.TabIndex = 10;
            // 
            // labelSubtotal2
            // 
            this.labelSubtotal2.AutoSize = true;
            this.labelSubtotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSubtotal2.Location = new System.Drawing.Point(526, 65);
            this.labelSubtotal2.Name = "labelSubtotal2";
            this.labelSubtotal2.Size = new System.Drawing.Size(0, 16);
            this.labelSubtotal2.TabIndex = 11;
            // 
            // labelPersen
            // 
            this.labelPersen.AutoSize = true;
            this.labelPersen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPersen.Location = new System.Drawing.Point(204, 98);
            this.labelPersen.Name = "labelPersen";
            this.labelPersen.Size = new System.Drawing.Size(20, 16);
            this.labelPersen.TabIndex = 12;
            this.labelPersen.Text = "%";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(49, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 51);
            this.panel1.TabIndex = 13;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelPersen);
            this.Controls.Add(this.labelSubtotal2);
            this.Controls.Add(this.labelTax2);
            this.Controls.Add(this.labelDisc2);
            this.Controls.Add(this.labelTotal2);
            this.Controls.Add(this.labelTax);
            this.Controls.Add(this.labelSubTotal);
            this.Controls.Add(this.labelDisc);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.buttonHitung);
            this.Controls.Add(this.textBoxInput);
            this.Controls.Add(this.labelInput);
            this.Controls.Add(this.checkBoxDisc);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.Label labelInput;
        private System.Windows.Forms.CheckBox checkBoxDisc;
        private System.Windows.Forms.Label labelSubtotal2;
        private System.Windows.Forms.Label labelTax2;
        private System.Windows.Forms.Label labelDisc2;
        private System.Windows.Forms.Label labelTotal2;
        private System.Windows.Forms.Label labelTax;
        private System.Windows.Forms.Label labelSubTotal;
        private System.Windows.Forms.Label labelDisc;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Button buttonHitung;
        private System.Windows.Forms.Label labelPersen;
        private System.Windows.Forms.Panel panel1;
    }
}