﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TugasWeek15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int[] hargamakanan = new int[4];
        public int[] hargaminuman1 = new int[4];
        public int[] hargaminuman2 = new int[4];

        private void ceklistbox()
        {
            if (listBoxMenu.Items.Count == 0)
            {
                buttonDelete.Enabled = false;

            }
            else
            {
                buttonDelete.Enabled = true;
            }
        }

        private void buttonBuy_Click(object sender, EventArgs e)
        {
            if (radioButtonMakanan.Checked == true)
            {
                listBoxMenu.Items.Add(comboBoxMakanan.SelectedItem);
            }
            else if (radioButtonMinuman.Checked == true)
            {
                listBoxMenu.Items.Add(comboBoxMinuman.SelectedItem);
            }
            listBoxHarga.Items.Add(Convert.ToInt32(labelHarga.Text));
            ceklistbox();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            listBoxHarga.Items.RemoveAt(listBoxMenu.SelectedIndex);
            listBoxMenu.Items.RemoveAt(listBoxMenu.SelectedIndex);
            ceklistbox();
        }

        private void buttonCheckOut_Click(object sender, EventArgs e)
        {
            if (listBoxMenu.Items.Count == 0)
            {
                MessageBox.Show("Choose Menu !");
            }
            else
            {
                var formbayar = new Form2();
                formbayar.Show();
            }
        }

        private void comboBoxMenu_SelectedIndexChanged(object sender, EventArgs e)
        { 
            if (radioButtonMakanan.Checked == true)
            {
                if (comboBoxMakanan.SelectedIndex == 0)
                {
                    labelHarga.Text = Convert.ToString(hargamakanan[0]);
                }
                if (comboBoxMakanan.SelectedIndex == 1)
                {
                    labelHarga.Text = Convert.ToString(hargamakanan[1]);
                }
                if (comboBoxMakanan.SelectedIndex == 2)
                {
                    labelHarga.Text = Convert.ToString(hargamakanan[2]);
                }
                if (comboBoxMakanan.SelectedIndex == 3)
                {
                    labelHarga.Text = Convert.ToString(hargamakanan[3]);
                }
            }
        }

        private void comboBoxMinuman_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (comboBoxMinuman.SelectedIndex == 0)
            {
                if (radioButtonNormal.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman1[0]);
                }
                else if (radioButtonJumbo.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman2[0]);
                }
            }
            if (comboBoxMinuman.SelectedIndex == 1)
            {
                if (radioButtonNormal.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman1[1]);
                }
                else if (radioButtonJumbo.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman2[1]);
                }
            }
            if (comboBoxMinuman.SelectedIndex == 2)
            {
                if (radioButtonNormal.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman1[2]);
                }
                else if (radioButtonJumbo.Checked = true)
                {
                    labelHarga.Text = Convert.ToString(hargaminuman2[2]);
                }
                if (comboBoxMinuman.SelectedIndex == 3)
                {
                    if (radioButtonNormal.Checked = true)
                    {
                        labelHarga.Text = Convert.ToString(hargaminuman1[3]);
                    }
                    else if (radioButtonJumbo.Checked = true)
                    {
                        labelHarga.Text = Convert.ToString(hargaminuman2[3]);
                    }
                }
            } 
        }


        private void radioButtonMakanan_CheckedChanged(object sender, EventArgs e)
        {
            comboBoxMinuman.Hide();
            comboBoxMakanan.SelectedIndex = 0;
            //groupBoxSize.Visible = false;
            labelSize.Visible = false;
            radioButtonJumbo.Visible = false;
            radioButtonNormal.Visible = false;
            labelHelp.Visible = false;
            if (radioButtonMinuman.Checked)
            {
                comboBoxMinuman.Visible = true;
                comboBoxMakanan.Hide(); 
                comboBoxMinuman.SelectedIndex = 0;
               // groupBoxSize.Visible = true;
               labelSize.Visible = true;
               radioButtonJumbo.Visible = true;
               radioButtonNormal.Visible = true;
                labelHelp.Visible = true;
            }
        }

        private void radioButtonMinuman_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void listBoxMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            hargamakanan[0] = 10000;
            hargamakanan[1] = 12000;
            hargamakanan[2] = 15000;
            hargamakanan[3] = 15000;
            hargaminuman1[0] = 5000;
            hargaminuman1[1] = 3000;
            hargaminuman1[2] = 6000;
            hargaminuman1[3] = 2000;
            hargaminuman2[0] = 7000;
            hargaminuman2[1] = 5000;
            hargaminuman2[2] = 10000;
            hargaminuman2[3] = 5000;
            ceklistbox();
        }
        
       public static int subtotal = 0;
        
       
    }
}
